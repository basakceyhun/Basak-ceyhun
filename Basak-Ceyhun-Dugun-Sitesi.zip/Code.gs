function doPost(e){
const folder=DriveApp.getFolderById("11-GOyH6lS5DrDlNWnPaGS9xm_J7GspcD");
const d=JSON.parse(e.postData.contents);
folder.createFile(Utilities.newBlob(Utilities.base64Decode(d.file),d.type,d.name));
return ContentService.createTextOutput(JSON.stringify({success:true})).setMimeType(ContentService.MimeType.JSON);
}