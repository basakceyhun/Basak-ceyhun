const WEB_APP_URL="https://script.google.com/macros/s/AKfycbw6UokA3WNc57xHd2-lSkhsfti6n0WQhu9OR42YsSrdzRg9arlrwASrGM4dGZGoD5Nm3A/exec";
async function uploadFiles(){
const files=document.getElementById('files').files;
if(!files.length){alert('Dosya seçin');return;}
const bar=document.getElementById('bar');
const status=document.getElementById('status');
for(let i=0;i<files.length;i++){
const f=files[i];
const b64=await new Promise(r=>{const fr=new FileReader();fr.onload=()=>r(fr.result.split(',')[1]);fr.readAsDataURL(f);});
const res=await fetch(WEB_APP_URL,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:f.name,type:f.type,file:b64})});
if(!res.ok){status.textContent='Hata oluştu';return;}
bar.style.width=((i+1)/files.length*100)+'%';
}
status.textContent='Teşekkür ederiz. Dosyalar yüklendi.';
}